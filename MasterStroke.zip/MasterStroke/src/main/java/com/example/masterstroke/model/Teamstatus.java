package com.example.masterstroke.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Teamstatus {
	@Id
	private String teamid;
	private int batsman;
	public String getTeamid() {
		return teamid;
	}
	public void setTeamid(String teamid) {
		this.teamid = teamid;
	}
	public int getBatsman() {
		return batsman;
	}
	public void setBatsman(int batsman) {
		this.batsman = batsman;
	}
	public int getBowler() {
		return bowler;
	}
	public void setBowler(int bowler) {
		this.bowler = bowler;
	}
	public int getWicketkeeper() {
		return wicketkeeper;
	}
	public void setWicketkeeper(int wicketkeeper) {
		this.wicketkeeper = wicketkeeper;
	}
	public int getAllrounder() {
		return allrounder;
	}
	public void setAllrounder(int allrounder) {
		this.allrounder = allrounder;
	}
	public int getIndian() {
		return indian;
	}
	public void setIndian(int indian) {
		this.indian = indian;
	}
	public int getOverseas() {
		return overseas;
	}
	public void setOverseas(int overseas) {
		this.overseas = overseas;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public int getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(int totalamount) {
		this.totalamount = totalamount;
	}
	public int getPurse() {
		return purse;
	}
	public void setPurse(int purse) {
		this.purse = purse;
	}
	public int getTotalplayers() {
		return totalplayers;
	}
	public void setTotalplayers(int totalplayers) {
		this.totalplayers = totalplayers;
	}
	public int getTotalcredit() {
		return totalcredit;
	}
	public void setTotalcredit(int totalcredit) {
		this.totalcredit = totalcredit;
	}
	private int bowler;
	private int wicketkeeper;
	private int allrounder;
	private int indian;
	private int overseas;
	private String teamname;
	private int totalamount;
	private int purse;
	private int totalplayers;
	private int totalcredit;
	
	
}
