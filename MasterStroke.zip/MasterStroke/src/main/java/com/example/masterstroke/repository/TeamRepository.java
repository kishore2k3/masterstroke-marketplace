package com.example.masterstroke.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.example.masterstroke.model.Teamstatus;

public interface TeamRepository extends JpaRepository<Teamstatus,String>{
	@Query("select f.batsman from Teamstatus f where f.teamid=?1")
	public int getBatsman(String id);
	
	@Query("select f.bowler from Teamstatus f where f.teamid=?1")
	public int getBowler(String id);
	
	@Query("select f.allrounder from Teamstatus f where f.teamid=?1")
	public int getAllrounder(String id);
	
	@Query("select f.wicketkeeper from Teamstatus f where f.teamid=?1")
	public int getWicketKeeper(String id);
	
	@Query("select f.indian from Teamstatus f where f.teamid=?1")
	public int getIndian(String id);
	
	@Query("select f.overseas from Teamstatus f where f.teamid=?1")
	public int getOverseas(String id);
	
	@Query("select f.purse from Teamstatus f where f.teamid=?1")
	public int getPurse(String id);
	
	@Query("select f.totalcredit from Teamstatus f where f.teamid=?1")
	public int getCredit(String id);
	
	@Query("select f.totalplayers from Teamstatus f where f.teamid=?1")
	public int getTotalplayer(String id);
	
	@Modifying
	@Query("update Teamstatus p set p.batsman=?1 where p.teamid=?2")
	public int updateBatsman(int n,String id);
	
	@Modifying
	@Query("update Teamstatus p set p.bowler=?1 where p.teamid=?2")
	public int updateBowler(int n,String id);
	
	@Modifying
	@Query("update Teamstatus p set p.allrounder=?1 where p.teamid=?2")
	public int updateAllrounder(int n,String id);
	
	@Modifying
	@Query("update Teamstatus p set p.wicketkeeper=?1 where p.teamid=?2")
	public int updateWicketkeeper(int n,String id);
	
	@Modifying
	@Query("update Teamstatus p set p.indian=?1 where p.teamid=?2")
	public int updateIndian(int n,String id);
	
	@Modifying
	@Query("update Teamstatus p set p.overseas=?1 where p.teamid=?2")
	public int updateOverseas(int n,String id);
	
	@Modifying
	@Query("update Teamstatus p set p.purse=?1, p.totalcredit=?2, p.totalplayers=?3 where p.teamid=?4")
	public int updateTeam(int purse,int credit,int total,String id);
	

}
