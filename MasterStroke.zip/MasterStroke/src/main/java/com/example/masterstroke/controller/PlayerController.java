package com.example.masterstroke.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.masterstroke.model.Player;
import com.example.masterstroke.model.Teamstatus;
import com.example.masterstroke.service.PlayerService;

@RestController
@CrossOrigin("http://localhost:3000/")
public class PlayerController {
	@Autowired
	PlayerService ser;
	@GetMapping("/getDataPlayer")
	public List<Player> getDataPlayer()
	{
		return ser.getDataPlayer();
	}
	@PostMapping("/postPlayerData")
	public String postData(@RequestBody Player p) {
		return ser.postDataSer(p);
	}
	@GetMapping("/getDataByCategory/{category}")
	public List<Player> getDataByCatergory(@PathVariable("category") String s){
		return ser.getDataByCategory(s);
	}
	@GetMapping("/verifyPlayer/{getId}")
	public String verifyPlayer(@PathVariable("getId") String s){
		return ser.verifyPlayer(s);
	}
	@GetMapping("/getData/{id}")
	public Optional<Player> getData(@PathVariable("id") String s) {
		return ser.getData(s);
	}
	@GetMapping("/getTeam")
	public List<Teamstatus> getTeam(){
		return ser.getTeam();
	}
	@PostMapping("/updataTeam")
	public String updateTeam(@RequestBody Teamstatus s) {
		return ser.updateTeam(s);
	}
	@PutMapping("/putData/{id}")
	public String putData(@RequestBody Teamstatus data,@PathVariable("id") String no)
	{
		return ser.putData(data,no);
	}
	@GetMapping("/updatePlayer/{teamname}/{amount}/{id}/{category}/{nation}")
	public int updatePlayer(@PathVariable("teamname") String s,@PathVariable("amount") float f,@PathVariable("id") String i,@PathVariable("category") String c,@PathVariable("nation") String n)
	{
		return ser.updatePlayer(s,f,i,c,n);
	}
	@GetMapping("/getTeamPlayer/{teamname}")
	public List<Player> getTeamPlayer(@PathVariable("teamname") String t){
		return ser.getTeamPlayer(t);
	}
}