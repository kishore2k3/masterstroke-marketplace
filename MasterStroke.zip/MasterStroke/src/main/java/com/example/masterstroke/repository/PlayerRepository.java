package com.example.masterstroke.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.masterstroke.model.Player;

@Repository
public interface PlayerRepository extends JpaRepository<Player,String>{
	@Query("select r from Player r where r.category=?1")
	List<Player> findByCategory(String category);
	
	@Modifying
	@Query("update Player p set p.teamname=?1, p.finalprice=?2 where p.playerid=?3")
	public int updatePlayer(String t,float f,String id);
	
	@Query("select f.point from Player f where f.playerid=?1")
	public int getCredit(String id);
	
	@Query("select f.teamname from Player f where f.playerid=?1")
	public String getTeamName(String id);
	
	public List<Player> findByTeamname(String teamname);
}	