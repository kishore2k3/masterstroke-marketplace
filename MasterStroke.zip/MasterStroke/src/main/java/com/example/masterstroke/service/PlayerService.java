package com.example.masterstroke.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.example.masterstroke.model.Player;
import com.example.masterstroke.model.Teamstatus;
import com.example.masterstroke.repository.PlayerRepository;
import com.example.masterstroke.repository.TeamRepository;

import jakarta.transaction.Transactional;

@Service
public class PlayerService {
	@Autowired
	PlayerRepository rep;
	@Autowired
	TeamRepository team;
	public List<Player> getDataPlayer() {
		return rep.findAll();
	}
	public String postDataSer(Player p) {
		Optional<Player> dta = rep.findById(p.getPlayerid());
		if(dta.isPresent())
		{
			return "ALREADY EXISTS";
		}
		else
		{
			rep.save(p);
			return "UPLOADED";
		}
	}
	public List<Player> getDataByCategory(String s) {
		return rep.findByCategory(s);
	}
	public String verifyPlayer(String s) {
		Optional<Player> dta = rep.findById(s);
		String team = rep.getTeamName(s);
		if(dta.isPresent() && team==null)
		{
			return "YES";
		}
		else
		{
			return "NO";
		}
	}
	public Optional<Player> getData(String s) {
		Optional<Player> dta = rep.findById(s);
		if(dta.isPresent())
		{
			return dta;
		}
		else
		{
			return null;
		}
	}
	public List<Teamstatus> getTeam() {
		String field = "totalcredit";
		String field2 = "purse";
		return team.findAll(Sort.by(Direction.DESC,field,field2));
	}
	public String updateTeam(Teamstatus s) {
		team.save(s);
		return "Saved";
	}
	public String putData(Teamstatus data, String no) {
		Optional<Teamstatus> dta=team.findById(no);
		if(dta.isPresent())
		{
			team.save(data);
			return "Updated Successfully";
		}
		return "Unsuccessfull";
	}
	@Transactional
	public int updatePlayer(String t,float f, String id,String c,String nation) {
		int s=rep.updatePlayer(t,f, id);
		if(c.equals("BATSMAN")) {
			int n= team.getBatsman(t);
			n++;
			s=team.updateBatsman(n, t);
		}
		else if(c.equals("BOWLER")) {
			int n= team.getBowler(t);
			n++;
			s=team.updateBowler(n, t);
		}
		else if(c.equals("ALLROUNDER")) {
			int n= team.getAllrounder(t);
			n++;
			s=team.updateAllrounder(n, t);
		}
		else if(c.equals("WICKETKEEPER")) {
			int n= team.getWicketKeeper(t);
			n++;
			s=team.updateWicketkeeper(n, t);
		}
		if(nation.equals("INDIA")) {
			int n= team.getIndian(t);
			n++;
			s= team.updateIndian(n, t);
		}
		else if(nation.equals("OVERSEAS")) {
			int n= team.getOverseas(t);
			n++;
			s=team.updateOverseas(n,t);
		}
		int purse = team.getPurse(t);
		int credit = team.getCredit(t);
		int total = team.getTotalplayer(t);
		int point = rep.getCredit(id);
		s = team.updateTeam(purse - (int)f, credit+point, total+1, t);
		return s;
	}
	public List<Player> getTeamPlayer(String t) {
		return rep.findByTeamname(t);
	}

}
