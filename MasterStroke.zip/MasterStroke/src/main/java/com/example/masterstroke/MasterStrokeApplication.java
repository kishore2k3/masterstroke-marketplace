package com.example.masterstroke;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterStrokeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasterStrokeApplication.class, args);
	}

}
